#ifndef Nabeel_Node
#define Nabeel_Node
#include <iostream>
#include<cstdlib>
#include <string>
using namespace std;
class Node
	{
	 public:
			
			Node( string & i_data);
			//~Node();
			void set_data ( string& i_data); 
			void set_next(  Node* next_node) ;
			void set_prev( Node* prev_node) ;
			
		    string get_data() ;
			Node* getNext();
			Node* getPrev();
			const Node* get_next() const;
			const Node* get_prev() const;
			
	 private:
			string data;
			Node* next;
			Node* prev;
	
	};



#endif