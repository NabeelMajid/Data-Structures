#include "LinkedList.h"
#include "Node.h"
#include<iostream>
#include<string>
using namespace std;
LinkedList::LinkedList()
    {
    head_ptr = NULL;
    tail_ptr = NULL;
    list_length = 0;
    }

   

   LinkedList::~LinkedList()
    {
        while(head_ptr != NULL)
         head_ptr=NULL ; 
        tail_ptr = NULL;
    }
	
	void LinkedList::add(const string  p_data)
	
	{
		 
		 
		 int i=0;
		 int found=0;
		string word="";
		while(found!=-1)
		{
			//cout<<i<<" ";
			
			found=p_data.find(" ",i);
			cout<<found<<" ";
			word=p_data.substr(i,found);
		    cout<<word<<" ";
		   // word.clear();
			
			
			if(list_length==0)
			{
					head_ptr=new Node(word);
					tail_ptr=head_ptr;
					list_length++;
			}
			else
			{
				Node* tail_insert = new Node(word);
				tail_ptr->set_next(tail_insert);
				tail_insert->set_prev(tail_ptr);
				tail_ptr = tail_insert;
				list_length++;
				tail_insert = NULL;
			}
			i=found+1;
			
			//cout<<list_length;
			word.clear();
			
			
		}
	}
	Node* LinkedList::getHead() const
	{
		return head_ptr;
	}
	ostream& operator << (ostream& out, const LinkedList& listl)
	{
		Node* current =listl.getHead();
		while(current!=NULL)
		{
			out<<current->get_data()<<endl;
			
		}
		
		return out;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	