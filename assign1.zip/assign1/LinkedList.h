#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include <cstdlib>
#include<string>
#include "Node.h"



    class LinkedList
    {
        public:
			
           
            LinkedList();
			~LinkedList();//
			void add(const string p_data);
			Node* getHead() const;

            
        private:
            Node* head_ptr;
            Node* tail_ptr;
            Node* current_ptr;
            std::size_t list_length =0;
    };
std::ostream& operator << (std::ostream& out, const LinkedList& listl);

#endif
