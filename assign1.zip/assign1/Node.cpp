#include "Node.h"
using namespace std;

	
	Node::Node( string & i_data )
	{
		data = i_data;
		next = NULL;
		prev = NULL;
	}
	
	//Mutators
	
	/*Node::~Node()
	{
		delete Node*;
	}*/
	
	void Node::set_data( string & i_data)
	{
		data = i_data;
	}
	
	void Node::set_next( Node* next_node)
	{
		next = next_node;
	}
	
	void Node::set_prev( Node* prev_node)
	{
		prev = prev_node;
	}
	
	//accessors
	string Node::get_data()
	{
		return data;
	}
	
	const Node* Node::get_next() const
	{
		return next;
	}
	
	const Node* Node::get_prev() const
	{
		return prev;
	}
	
	Node* Node::getNext()
	{
		return next;
	}
	
	Node* Node::getPrev()
	{
		return prev;
	
	}
	
