// SENG1120 Staff (Josephus) - 2020

#ifndef SENG1120_BTREE
#define SENG1120_BTREE

#include <ostream>
#include <math.h>
#include <vector>

using namespace std;

template <typename value_type>
class BTree
{
public:
	BTree(int capacity);
	~BTree();

	bool isEmpty();
	void push(const value_type& data);
	value_type pop();

	ostream& print(ostream& out);

private:
	int size;
	vector<value_type> data;

	bool hasLeftChild(int index);
	bool hasRightChild(int index);
	value_type leftChild(int index);
	value_type rightChild(int index);

	void swap(int indexA, int indexB);
	void bubbleUp(int index);
	void bubbleDown(int index);
};

template <typename value_type>
ostream& operator << (ostream& out, BTree<value_type>& tree);

#include "BTree.hpp"

#endif
