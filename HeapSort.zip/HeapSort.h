// SENG1120 Staff (Josephus) - 2020

#ifndef SENG1120_HEAPSORT
#define SENG1120_HEAPSORT

#include <ostream>
#include "BTree.h"

using namespace std;

template <typename value_type>
class HeapSort
{
public:
	HeapSort(int capacity);
	~HeapSort();

	void enqueue(const value_type& data);
	value_type dequeue();
	bool isEmpty();
	ostream& print(ostream& out);

private:
	BTree<value_type>* tree;
};

#include "HeapSort.hpp"

#endif
