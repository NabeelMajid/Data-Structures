// SENG1120 Staff (Josephus) - 2020

template <typename value_type>
HeapSort<value_type>::HeapSort(int capacity)
{
	tree = new BTree<value_type>(capacity);
}

template <typename value_type>
HeapSort<value_type>::~HeapSort()
{
	delete tree;
}

template <typename value_type>
void HeapSort<value_type>::enqueue(const value_type& data)
{
	tree->push(data);
}

template <typename value_type>
value_type HeapSort<value_type>::dequeue()
{
	return tree->pop();
}

template <typename value_type>
bool HeapSort<value_type>::isEmpty()
{
	return tree->isEmpty();
}

template <typename value_type>
ostream& HeapSort<value_type>::print(ostream& out)
{
    return tree->print(out);
}
