// Demo - HeapSort sample
// By : SENG1120 Staff
// Notes : This program demonstrates the functionality of HeapSort
//         using an vector-based Binary Tree

#include <iostream>
#include "HeapSort.h"

using namespace std;

int main()
{
    int itemCount;
    cout << "number of items to sort: ";
    cin >> itemCount;

    HeapSort<int> heap(itemCount);

    int input;
    for (int i = 0; i < itemCount; i++) {
        cout << "enter an integer, " << i + 1 << " of " << itemCount << ": ";
        cin >> input;
        heap.enqueue(input);
    }

    cout << endl << endl;

    cout << "heap contents (parent: left, right)" << endl;
    heap.print(cout);

    cout << endl << endl;

    cout << "items, sorted max to min:" << endl;

    while (!heap.isEmpty()) {
        cout << heap.dequeue() << " ";
    }

	return 0;
}
