// SENG1120 Staff (Josephus) - 2020

template <typename value_type>
BTree<value_type>::BTree(int initialCapacity)
{
	data = vector<value_type>(initialCapacity);
	size = 0;
}

template <typename value_type>
BTree<value_type>::~BTree()
{
	//
}

template <typename value_type>
bool BTree<value_type>::isEmpty()
{
	return size == 0;
}

template <typename value_type>
void BTree<value_type>::push(const value_type& value)
{
	int nextIndex = size;
	data[nextIndex] = value;
	bubbleUp(nextIndex);
	size++;
}

template <typename value_type>
value_type BTree<value_type>::pop()
{
	if (size == 0) {
        return value_type();
    }

    value_type value = data[0];

    if (size == 1) {
        size--;
    } else {
        int rootIndex = 0;
        int lastIndex = size - 1;

        swap(rootIndex, lastIndex);
        size--;

        bubbleDown(rootIndex);
    }

    return value;
}

template <typename value_type>
void BTree<value_type>::bubbleUp(int index)
{
	int parentIndex = floor((index - 1) / 2);

    if (data[index] > data[parentIndex]) {
        swap(index, parentIndex);
        bubbleUp(parentIndex);
    }
}

template <typename value_type>
void BTree<value_type>::bubbleDown(int index)
{
	int leftIndex = 2 * index + 1;
    int rightIndex = 2 * index + 2;
    int lastIndex = size - 1;

    int largestIndex = index;

    if (leftIndex <= lastIndex && data[largestIndex] < data[leftIndex]) {
        largestIndex = leftIndex;
    }

    if (rightIndex <= lastIndex && data[largestIndex] < data[rightIndex]) {
        largestIndex = rightIndex;
    }

    if (index != largestIndex) {
        swap(index, largestIndex);
        bubbleDown(largestIndex);
    }
}

template <typename value_type>
void BTree<value_type>::swap(int indexA, int indexB) {
	value_type temp = data[indexA];
    data[indexA] = data[indexB];
    data[indexB] = temp;
}

template <typename value_type>
bool BTree<value_type>::hasLeftChild(int index) {
	int leftIndex = 2 * index + 1;
	return leftIndex < size;
}

template <typename value_type>
bool BTree<value_type>::hasRightChild(int index) {
	int rightIndex = 2 * index + 2;
	return rightIndex < size;
}

template <typename value_type>
value_type BTree<value_type>::leftChild(int index) {
	int leftIndex = 2 * index + 1;
	return data[leftIndex];
}

template <typename value_type>
value_type BTree<value_type>::rightChild(int index) {
	int rightIndex = 2 * index + 2;
	return data[rightIndex];
}

template <typename value_type>
ostream& BTree<value_type>::print(ostream& out)
{
    for (int i = 0; i < size; i++) {
    	out << data[i] << ": ";
    	if (hasLeftChild(i)) {
    		out << leftChild(i);
    	} else {
    		out << " ";
    	}
    	out << ", ";
    	if (hasRightChild(i)) {
    		out << rightChild(i);
    	} else {
    		out << " ";
    	}
    	out << std::endl;
    }

    return out;
}

template <typename value_type>
ostream& operator << (ostream& out, BTree<value_type>& tree)
{
	return tree.print(out);
}
