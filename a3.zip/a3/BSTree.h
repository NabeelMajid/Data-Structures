// SENG1120 Staff (Dan and Tim) - 2019

#ifndef SENG1120_BSTREE
#define SENG1120_BSTREE

#include <cstdlib>
#include <ostream>
#include "BTNode.h"

using namespace std;

template <typename value_type>
class BSTree
{
public:
	// Constructor
	BSTree();			//done
	// Destructor
	~BSTree();			//done
	void remove(BTNode<value_type>* node);									//
	void add(const value_type& data);												//done
	void remove(const value_type& data);											//ok
	int get_size() const;															//ok
	
	ostream& print(ostream& out);
private:
	BTNode<value_type>* root_node;
	int size;

	// Recursing helper methods
	BTNode<value_type>* find_min(BTNode<value_type>* const node) const;
	BTNode<value_type>* add(const value_type& data, BTNode<value_type>* node);			//ok
	BTNode<value_type>* remove(const value_type& data, BTNode<value_type>* node);		//ok
	ostream& print(ostream& out, const BTNode<value_type>* node);

	};

template <typename value_type>
ostream& operator << (ostream& out, BSTree<value_type>& tree);


#include "BSTree.hpp"
#endif

