// SENG1120 Staff (Dan and Tim) - 2019

#ifndef SENG1120_BTNODE
#define SENG1120_BTNODE

#include <cstdlib>
#include <ostream>

using namespace std;

template <typename value_type>
class BTNode
{
	public:

		// Constructors
		BTNode();
		//BTNode(const value_type& initial_data = value_type());
		BTNode(const value_type& initial_data = value_type(), BTNode* initParent = NULL, BTNode* initLeft = NULL, BTNode* initRight = NULL);

		// Destructor
		~BTNode();

		// Setters
		void set_data(const value_type& new_data);
		void set_parent(BTNode<value_type>* new_parent);
		void set_left(BTNode<value_type>* new_left);
		void set_right(BTNode<value_type>* new_right);

		// Getters
		value_type get_data();
		const value_type get_data() const;
		BTNode<value_type>* get_parent();
		const BTNode<value_type>* get_parent() const;
		BTNode<value_type>* get_left();
		const BTNode<value_type>* get_left() const;
		BTNode<value_type>* get_right();
		const BTNode<value_type>* get_right() const;

		//BTNode<value_type>* remove(value_type data, BTNode<value_type>* parent);
		//value_type minimum_value();

	private:
		value_type data;
		BTNode<value_type>* parent;
		BTNode<value_type>* left;
		BTNode<value_type>* right;
};



template <typename value_type>
ostream& operator << (ostream& out, const BTNode<value_type>& BTNode);

#include "BTNode.hpp"

#endif