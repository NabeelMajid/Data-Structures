/********************************************************************************************************************************
 * 	A template named as HTable.h is made here, Place this file in your project, include this template in your file that
 * 	have main function and use it in your main function
 *******************************************************************************************************************************/
#include<iostream>
#include<cstdlib>
#include<string>
#include<cstdio>
using namespace std;

/********************************************************************************************************************************
 * 	constant T_S defines length of hash table
 *******************************************************************************************************************************/
const int T_S = 150;

/*******************************************************************************************************************************
 *  Class HashTableEntry has required abtributes of hashtable and a constructor
 *******************************************************************************************************************************/
template <typename Type>
class HashTableEntry 
{
   public:
      int key;
      string value;
      HashTableEntry(int key, string value) 
	  {
         this->key= key;
         this->value = value;
      }
};

/*********************************************************************************************************************************
 * 	Class HTable has all attributes and Methods that hashTable requires
 *********************************************************************************************************************************/
template <typename Type>
class HTable
 {
   public:
      HashTableEntry<Type> **t;
   public:

/*********************************************************************************************************************************
 * Contructor of hashtable having Time Complexity : O(n)
 ********************************************************************************************************************************/
      HTable() 
	  {
         t = new HashTableEntry<Type> * [T_S];
         for (int i = 0; i< T_S; i++) {
            t[i] = NULL;
         }
      }
/********************************************************************************************************************************
 *  hashfun() computes the hashing value of data
 *  Time Complexity : O(n)
 *******************************************************************************************************************************/
      int hashfun(Type value) {
    	  int addResult = 0;

    	  for (int i = 0; i<value.size(); i++) {
    		  addResult = addResult + value [i];
    	  }
    	  return addResult % 150;
      }

/********************************************************************************************************************************
 * 	add() is used for adding data into hashtable
 * 	Time Complexity of computing hash : O(n)
 * 	Time complexity of adding in hashtable : O(1)
 *******************************************************************************************************************************/
      void add( Type v) 
	  {
         int h = hashfun(v);
         if (t[h] != NULL)
            delete t[h];
         t[h] = new HashTableEntry<Type>(h, v);
      }

/********************************************************************************************************************************
* 	SearchKey() is used for searching data from hashtable
* 	Time Complexity of computing hash : O(n)
* 	Time complexity of searching from hashtable : O(1)
*******************************************************************************************************************************/
      int SearchKey(Type v) {
         int h = hashfun(v);
         if (t[h] == NULL)
            return -1;
         else
            return t[h]->key;
      }

/********************************************************************************************************************************
* 	remove() is used for removing data from hashtable
* 	Time Complexity of computing hash : O(n)
* 	Time complexity of removing from hashtable : O(1)
*******************************************************************************************************************************/
      void remove(Type v) {
         int h = hashfun(v);

         if (t[h] == NULL) {
            cout<<"No Element found at key "<<h<<endl;
            return;
         } else {
            delete t[h];
            t[h] = NULL;
         }
      //   cout<<"Element Deleted"<<endl;
      }

/********************************************************************************************************************************
* 	~HTable() is a destructor
* 	Time Complexity : O(n)
*******************************************************************************************************************************/
~HTable() 
	{
         for (int i = 0; i < T_S; i++) {
            if (t[i] != NULL)
               delete t[i];
               delete[] t;
         }
     }

/********************************************************************************************************************************
* 	print() is a utility function used for printing hash table, Output operator overloading used it
* 	Time Complexity : O(n)
*******************************************************************************************************************************/
      void print(ostream& out )const
          {
    	  if (t != NULL)
      	    for(int i = 0;i<T_S;i++) {
      	    	if(t[i] !=NULL){
//      	    	cout<<t[i]->key;
//      	    	cout<<<< " ";
      	    		cout<< t[i]->value<<endl;
      	    	}
      	    }
          }


/********************************************************************************************************************************
* 	output operator is overloaded for printing hash table
*****************************************************************************************************************************/
 friend ostream&  operator<<(ostream& out, const HTable& v)//remove
 {
     v.print(out);
     return out;
 }
};
