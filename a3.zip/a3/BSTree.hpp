

template <typename value_type>
BSTree<value_type>::BSTree()
{
	root_node = NULL;
	size = 0;
}

template <typename value_type>
BSTree<value_type>::~BSTree()
{
	remove(root_node);
}

template <typename value_type>
void BSTree<value_type>::add(const value_type& data)
{
	if (root_node == NULL)
	{
		root_node = new BTNode<value_type>(data);
		size++;
		return;
	}
	else
	{
		//recursive_add(data, root_node);
		add(data, root_node);
	}
}
template <typename value_type>
BTNode<value_type>* BSTree<value_type>::add(const value_type& data, BTNode<value_type>* node)
{
	int value=0;
	value=strcmpi(data,node->get_data);
	//it will return less than 0 if data is greater than node->get_data  and less than 0 if data is less than node->get_data
	if (value>0)//for left side
	{
		// Check current node 
		if (node->get_left())
		{
			// set left node
			node->set_left(add(data, node->get_left()));
		}
		else
		{
			node->set_left(new BTNode<value_type>(data, node));
			size++;
		}
	}

	if (value<0)
	{
		if (node->get_right())
		{
			node->set_right(add(data, node->get_right()));
		}
		else
		{
			node->set_right(new BTNode<value_type>(data, node));
			size++;
		}
	}


	return node;
}

//to delete from root node
template <typename value_type>
void BSTree<value_type>::remove(const value_type& data) 
{
	BTNode<value_type>* root = root_node;
	root = remove(data, root);
	//return true;
}
template <typename value_type>
BTNode<value_type>* BSTree<value_type>::remove_(const value_type& data, BTNode<value_type>* node)
{
	BTNode<value_type>* temp;
	if (node == NULL)
	{
		return NULL;
	}
int num=0;
	num=strcmp(data,node->get_data);
	if (num>0)
	{
		node->set_left(remove(data, node->get_left()));

		if (node->get_left())
		{
			node->get_left()->set_parent(node);
		}
	}
	else if (num<0)
	{
		node->set_right(remove(data, node->get_right()));

		if (node->get_right())
		{
			node->get_right()->set_parent(node);
		}
	}
	else
	{
		// for 2 child
		if (node->get_left() && node->get_right())
		{
			temp = find_min(node->get_right());
			node->set_data(temp->get_data());
			node->set_right(remove(node->get_data(), node->get_right()));
		}
		else // not 2 children
		{
			temp = node;
			// check left
			if (node->get_left() == NULL)
			{
				node = node->get_right();
			}
			else if (node->get_right() == NULL)
			{
				node = node->get_left();
			}
			delete temp;
			size--;
		}
	}

	// Check node 
	if (!node) 
	{
		return node;
	}

	return node;
}
template<typename value_type>
BTNode<value_type>* BSTree<value_type>::find_min(BTNode<value_type>* const node) const
{
	if (node == NULL)
	{
		return NULL;
	}

	if (node->get_left() == NULL) {
		// FOUND IT
		return node;
	}

	return find_min(node->get_left());
}
template <typename value_type>
ostream& operator << (ostream& out, BSTree<value_type>& tree)
{
	return tree.print(out);
}
template <typename value_type>
ostream& BSTree<value_type>::print(ostream& out, const BTNode<value_type>* node)
{
	// PREORDER
	//	left
	//		parent
	//	right
	if (node != NULL)
	{
		// left
		print(out, node->get_left());
		// parent
		out << node->get_data() << " ";
		// right
		print(out, node->get_right());
	}
	return out;
}
template <typename value_type>
ostream& BSTree<value_type>::print(ostream& out)
{
	BTNode<value_type>* root = root_node;
	return print(out, root);
}

