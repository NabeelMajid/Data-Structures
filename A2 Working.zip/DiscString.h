#ifndef DiscString_H
#define DiscString_H
#include <string>
using namespace std;
class DiscString
{
	public: 
	void createDisc(int pos);
	string getData()const;
	
	
	private: 
	
	string data ;
	
};
#endif