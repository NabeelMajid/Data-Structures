#include"TowerHanoi.h"
template <typename value_type>
TowerHanoi<value_type>::TowerHanoi(int nod)
{
	for(int i=1;i<=nod;i++)
	{
		DiscInt num1;
		num1.createDisc(i);
		rod_1.push(num1);
		/*DiscString disc;
		disc.createDisc(i);
		rod_1.push(disc);*/
	}
}

template <typename value_type>
void TowerHanoi<value_type>::move( int num1 , int num2 )
{
	
	if(num1==1)
	{
		value_type data;
		data = rod_1.pop();
		
		if (num2==2)
		{
		rod_2.push(data);
			
		}
		else if(num1==3)
		{
			rod_3.push(data);
		}
	}
	else if (num1==2)
	{
		value_type data;
		data = rod_2.pop();
		
		if (num2==1)
		{
		rod_1.push(data);
			
		}
		else if(num1==3)
		{
			rod_3.push(data);
		}
	}
	else if(num1==3)
	{
		value_type data;
		data = rod_3.pop();
		
		if (num2==1)
		{
		rod_1.push(data);
			
		}
		else if(num1==2)
		{
			rod_2.push(data);
		}
	}
}
template <typename value_type>
Stack<value_type> TowerHanoi<value_type>::getRod_1()
{
	return rod_1;
}
template <typename value_type>
Stack<value_type> TowerHanoi<value_type>::getRod_2()
{
	return rod_2;
}
template <typename value_type>
Stack<value_type> TowerHanoi<value_type>::getRod_3()
{
	return rod_3;
}
template <typename value_type>
bool TowerHanoi<value_type>::checkWin()
{
	if (rod_3.size()==5)
	{
		return true;
	}
	else false;
}
template <typename value_type>
ostream& operator << (ostream& out, TowerHanoi<value_type>& T)
{
	out << T.getRod_1() << T.getRod_2() << T.getRod_3();
	out << "-------------------------------------------------------------------";
	out << "/t1" << "/t2" << "/t3";
	return out;
}














