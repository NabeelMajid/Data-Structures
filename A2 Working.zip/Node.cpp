// Name: Nabeel Majid
// Student no: c3287060
//Course: SENG1120 (Data Structures)
//Assignment1
//*************************************************
#include "Node.h"
//pre-condition: take one parameter of string 
//post-condition: none
	//creating a node with one parameter
	template <typename value_type>
	Node<value_type>::Node( value_type & i_data )
	{
		data = i_data;//store a word from a string that we are passing from linklist and store in node
		next = NULL;
		prev = NULL;
	}
	
	//Mutators
	//pre-condition: none 
    //post-condition: delete the node
	template <typename value_type>
	Node<value_type>::~Node()
	{
		delete next;
		delete prev;
		//data.erase (value_type.begin(), value_type.end());
	}
	
	//pre-condition: take one parameter of string 
    //post-condition: set i_data (Which we are passing from linkedlist to node)  
	template <typename value_type>
	void Node<value_type>::set_data( value_type & i_data)
	{
		data = i_data;
	}
	
	
	//pre-condition: take one parameter of string 
    //post-condition: set the next pointer of the node to next node
	template <typename value_type>
	void Node<value_type>::set_next( Node* next_node)
	{
		next = next_node;
	}
	
	//pre-condition: take one parameter of string 
    //post-condition: set the prev pointer of the node to its prev node
	template <typename value_type>
	void Node<value_type>::set_prev( Node* prev_node)
	{
		prev = prev_node;
	}
	
	//accessors
	
	
	//pre-condition: return value should be value type 
    //post-condition: return data
	template <typename value_type>
	value_type Node<value_type>::get_data() const
	{
		return data;
	}

	//pre-condition: none 
    //post-condition: should return node* 
	template <typename value_type>
	Node<value_type>* Node<value_type>::getNext()
	{
		return next;
	}
	
	//pre-condition: none 
    //post-condition: should return node* 
	template <typename value_type>
	Node<value_type>* Node<value_type>::getPrev()
	{
		return prev;
	
	}
	
	//pre-condition: none 
	//post-condition: should const return node*
	template <typename value_type>
	const Node<value_type>* Node<value_type>::get_next() const
	{
		return next;
	}

	//pre-condition: none 
	//post-condition: should return const  node* 
	template <typename value_type>
	const Node<value_type>* Node<value_type>::get_prev() const
	{
		return prev;
	}

	template class Node<string>;