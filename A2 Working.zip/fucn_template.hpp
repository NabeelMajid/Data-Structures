#include "LinkedList.h"
#include "Node.h"
#include "DiscInt.h"
#include "DiscString.h"
#include "Stack.h"
template <typename value_type>
Stack<value_type>::Stack()
 {
	 
 }
 
/*template <typename value_type>
LStack<value_type>::~Stack() 
{
	
}*/
template <typename value_type>
Stack<value_type>::push(value_type value)
{
data.add_to_head(value);
used++;
}
template <typename value_type>
value_type Stack<value_type>::pop()
{
return data.remove_from_head();
used--;
}

template <typename value_type>
bool Stack<value_type>::isEmpty()
{
	if (used==0)
	{
		return true;
		
	}
	else 
		false;
}

template <typename value_type>
int Stack::size()
{
	return used;
}
