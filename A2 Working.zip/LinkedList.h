#pragma once
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Node.cpp"
#include "Node.h"
#include<iostream>
#include<string>
using namespace std;
	template<typename value_type>
    class LinkedList
    {
        public:            
         LinkedList();

         ~LinkedList();

         void add_to_head(value_type& data);
         
         value_type takeFromHead();
         Node<value_type>* getHead() const;
        private:
            Node<value_type>* head_ptr;
            Node<value_type>* tail_ptr;
			int list_length;
    };
    template <typename value_type>
    std::ostream& operator << (std::ostream& out, const LinkedList<value_type>& data);


#endif
