#include"DiscInt.h"
#include<iostream>

void DiscInt::createDisc(int pos)
{
	if (pos==1)
	{
		data=1;
	}
	else if (pos==2)
	{
		data=2;
	}
	else if (pos==3)
	{
		data=3;
	}
	else if (pos==4)
	{
		data=4;
	}
	else if (pos==5)
	{
		data=5;
	}
}
int DiscInt::getData() const
{
	return data;
}
ostream& operator<<(ostream& out, const DiscInt& d) {
	out << d.getData();
}