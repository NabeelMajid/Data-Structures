#pragma once
#ifndef Nabeel_Node
#define Nabeel_Node
#include <iostream>
#include<cstdlib>
#include <string>
using namespace std;
template <typename value_type>
class Node
	{
	 public:
			
			Node( value_type& i_data);
			~Node();
			void set_data ( value_type& i_data); 
			void set_next(  Node* next_node) ;
			void set_prev( Node* prev_node) ;
			
		    value_type get_data() const;
			Node* getNext();
			Node* getPrev();
			const Node* get_next() const;
			const Node* get_prev() const;
			
	 private:
			value_type data;
			Node* next;
			Node* prev;
	
	};



#endif