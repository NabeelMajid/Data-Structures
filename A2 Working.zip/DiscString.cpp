#include"DiscString.h"
void DiscString::createDisc(int pos)
{
	if (pos==1)
	{
		data="X";
	}
	else if (pos==2)
	{
		data="XXX";
	}
	else if (pos==3)
	{
		data="XXXXX";
	}
	else if (pos==4)
	{
		data="XXXXXXX";
	}
	else if (pos==5)
	{
		data="XXXXXXXXX";
	}
}
string DiscString::getData() const
{
	return data;
}
//ostream& operator<<(ostream& out, const DiscString& d) {
//	out << d.getData();
//}