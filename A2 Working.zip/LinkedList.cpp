#include "LinkedList.h"

template <typename value_type>
LinkedList<value_type>::LinkedList()
{
    list_length = 0;
	head_ptr=NULL;
	tail_ptr=NULL;
}
template <typename value_type>
LinkedList<value_type>::~LinkedList()
{
	delete head_ptr;
	delete tail_ptr;
}



template<typename value_type>
void LinkedList<value_type>::add_to_head(value_type& value) 
{
    	if(list_length>=0)
        {
            head_ptr = new Node<value_type>(value);
            tail_ptr = head_ptr;
            list_length++;
        }
        else
        {
            Node <value_type>* head_insert = new Node<value_type>(value);
            head_ptr->set_prev(head_insert);
            head_insert->set_next(head_ptr);

            head_ptr = head_insert;

            list_length++;

            head_insert = NULL;
        }
}
template<typename value_type>
Node<value_type>* LinkedList<value_type>::getHead() const {
    return head_ptr;
}
template<typename value_type>//find solution
 value_type LinkedList<value_type>::takeFromHead(){
            Node<value_type>* temp = head_ptr;
            head_ptr = head_ptr->getNext();
            temp->set_next( NULL);
			head_ptr->set_prev(NULL);
			value_type data;
			data= temp->get_data();
			delete temp;
			list_length--;
            return data;   // really bad! this will memory leak
}
 template <typename value_type>
 ostream& operator << (ostream& out, const LinkedList<value_type>& data)
 {
     Node<value_type>* current = data.getHead();
     while (current != NULL) { // traverses the linked list until the last element
         out << "/t" << current-> get_data() << "->"; // prints the content of node pointed to by current
         current = current->getNext(); // goes to the next node
     }

     return out;
 }