#ifndef TowerHanoi_H
#define TowerHanoi_H

#include "Stack.h"
#include "Stack.cpp"

using namespace std;
template<typename value_type>
class TowerHanoi
{
	public:
	TowerHanoi(int);
	void move(const int ,const int );
	bool checkWin();
	Stack<value_type> getRod_1();
	Stack<value_type> getRod_2();
	Stack<value_type> getRod_3();

	private:
	Stack<value_type> rod_1;
	Stack<value_type> rod_2;
	Stack<value_type> rod_3; 
};

template<typename value_type>
ostream& operator << (ostream& out, TowerHanoi<value_type>& T);
#endif
