#include "Stack.h"
using namespace std;

template <typename value_type>
Stack<value_type>::Stack()
{
	used = 0;
}


/*template <typename value_type>
LStack<value_type>::~Stack()
{

}*/
template <typename value_type>
void Stack<value_type>::push(value_type value)
{
	data.add_to_head(value);
	used++;
}
template <typename value_type>
value_type Stack<value_type>::pop()
{
	return data.takeFromHead();
	used--;
}

template <typename value_type>
bool Stack<value_type >::isEmpty() const
{
	if (used == 0)
	{
		return true;

	}
	else
		false;
}
template <typename value_type>
LinkedList<value_type> Stack<value_type>::getData() const
{
	return data;
}

template <typename value_type>
int Stack<value_type>::size()const
{
	return used;
}
template <typename value_type>
ostream& operator << (ostream& out, const Stack<value_type>& st)
{
	out << st.getData();
	return out;
}
