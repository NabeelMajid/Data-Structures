#pragma once
#ifndef Stack_H
#define Stack_H
#include<fstream>
#include<istream>
#include<iostream>
#include<string>
#include "LinkedList.h"
#include "DiscInt.h"
#include "DiscString.h"
#include "LinkedList.cpp"
#include "DiscInt.cpp"
#include "DiscString.cpp"
using namespace std;

template<typename value_type>
class Stack
{
	public:
	Stack();
	//~LStack();*/
	void push(value_type value);
	value_type pop();
	//value_type& peek();
	bool isEmpty() const;
	int size() const;
	LinkedList<value_type> getData()const;
private:
		LinkedList<value_type> data; 
		int used;
};
template<typename value_type>
ostream& operator << (ostream& out, const Stack<value_type>& st);
#endif
