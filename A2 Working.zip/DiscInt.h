#ifndef DiscInt_H
#define DiscInt_H
#include<iostream>
using namespace std;
class DiscInt
{
	public: 
	
	void createDisc(int pos );
	int getData() const;
	
	
	private: 
	int data ;
	
};
#endif